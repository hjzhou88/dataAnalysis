# -*- coding: utf-8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
import sys
import os
from merge import Ui_merge



class mergeDialog(QDialog,Ui_merge):
    def __init__(self,parent=None):
        super(mergeDialog,self).__init__(parent)
        self.setupUi(self)
        self.listWidget.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.listWidget_2.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.pushButton.clicked.connect(self.Bclick)
        self.pushButton_4.clicked.connect(self.B4click)
        self.pushButton_5.clicked.connect(self.B5click)

    def Bclick(self):
        #fileName=QFileDialog.getOpenFileName(self,"change path","C:\Users\Administrator\Desktop","Text Files (*.shp);;All Files (*)")   #设置文件扩展名过滤,注意用双分号间隔
        fileName=QFileDialog.getExistingDirectory()
        fileName.replace('\\',r'/')
        #print str(fileName)
        #fileName.replace('\','/')
        if not fileName.isEmpty():
            fileList=[]
            self.lineEdit.setText(fileName)
            fileList=self.GetFileList(str(fileName),fileList)
            for i in range(0,len(fileList)):
                #print fileList[i]
                self.listWidget.insertItem(i,fileList[i].replace('\\',r'/'))
            

    def B4click(self):
        #lenlist=len(self.listWidget.selectedItems()) #此种方法顺序不一致
        #t=0
        #while (t<lenlist):
            #index=self.listWidget.currentRow()
            #self.listWidget_2.insertItem(index,self.listWidget.takeItem(index))
            #t+=1
        itemlist=self.listWidget.selectedItems()  #此种方法顺序一致
        for i in itemlist:
            self.listWidget.takeItem(self.listWidget.row(i))  #row获得ITEM行号
            self.listWidget_2.addItem(i)

    def B5click(self):
        itemlist=self.listWidget_2.selectedItems()
        for i in itemlist:
            self.listWidget_2.takeItem(self.listWidget_2.row(i))  #row获得ITEM行号
            self.listWidget.addItem(i)

    def GetFileList(self,dir,fileList):
        newDir = dir
        if os.path.isfile(dir):
            fileList.append(dir.encode('gbk'))
        elif os.path.isdir(dir):
            for s in os.listdir(dir):
                #如果需要忽略某些文件夹，使用以下代码
                #if s == "xxx":
                #continue
                newDir=os.path.join(dir,s)
                self.GetFileList(newDir, fileList)
        return fileList 
