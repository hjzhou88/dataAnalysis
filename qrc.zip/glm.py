# coding:utf-8
#经测试该程序可行
import pandas as pd
from numpy import *
from scipy.stats import norm


class GLM():
        
        def sigmoid(self,x):
                u=1/(1+exp(-x))
                return u

        def findbeta(self,xdata,ydata):
                matxdata=mat(xdata)
                matydata=mat(ydata)
                beta=linalg.inv(matxdata.T*matxdata)*matxdata.T*matydata
                return beta

        def glm(self,x_data,y_data,link,distr):
                x_data=x_data.astype(float)   #避免传入的数据是object型
                y_data=y_data.astype(float)
                numSamples,numFeatures=x_data.shape
                add=ones((numSamples,1))
                x_tran=column_stack((add,x_data))
                b=ones((numFeatures+1,1))
                if link=="identity":           #此处两个“==”表示判断容易出错
                        b=array(self.findbeta(x_tran,y_data))
                u=zeros((numFeatures+1,1))
                jo=zeros((numFeatures+1,numFeatures+1))
                n,d=y_data.shape
                if d==1:
                        y_data=mat(column_stack((y_data,add)))
                while True:
                        temp_b=b
                        if link=="logit":
                                output=self.sigmoid(mat(x_tran)*mat(temp_b))
                                diffu=array(y_data[:,1])*array(output)*array(1-output)
                        if link=="log":
                                output=exp(mat(x_tran)*mat(temp_b))
                                diffu=array(y_data[:,1])/array(output)
                        if link=="identity":
                                output=mat(x_tran)*mat(temp_b)
                                diffu=array(y_data[:,1])
                        if link=="inverse":
                                output=-1/array(mat(x_tran)*mat(temp_b))
                                diffu=-array(y_data[:,1])*power(array(output),2)
                        if link=="pinverse":
                                output=power(array(mat(x_tran)*mat(temp_b)),-0.5)
                                diffu=array(y_data[:,1])*(-0.5)*power(array(output),3)
                        if distr=="binomial":
                                vary=diffu
                        if distr=="gama":
                                vary=array(output)*array(output)*array(y_data[:,1])
                        if distr=="poisson":
                                vary=array(output)*array(y_data[:,1])
                        if distr=="igaussian":
                                vary=power(array(output),3)*array(y_data[:,1])
                        error=array(y_data[:,0]-array(y_data[:,1])*array(output))*diffu/vary
                        u=mat(x_tran).T*mat(error)
                        byout=array(diffu*diffu/vary)
                        out=byout*array(x_tran)  #利用数组乘法避免大矩阵
                        jo=mat(x_tran).T*mat(out)
                        b=temp_b+linalg.inv(mat(jo))*u
                        if float((b-temp_b).T*(b-temp_b))<0.001:
                                break
                if link=="logit":
                        output=sigmoid(mat(x_tran)*mat(b))
                        estimatey=array(y_data[:,1])*array(output)
                if link=="log":
                        output=exp(mat(x_tran)*mat(b))
                        estimatey=array(y_data[:,1])*array(output)
                if link=="identity":
                        output=mat(x_tran)*mat(b)
                        estimatey=array(y_data[:,1])*array(output)
                if link=="inverse":
                        output=-1/array(mat(x_tran)*mat(b))
                        estimatey=array(y_data[:,1])*array(output)
                if link=="pinverse":
                        output=power(array(mat(x_tran)*mat(b)),-0.5)
                        estimatey=array(y_data[:,1])*array(output)
                if distr=="binomial":
                        ratio=log(abs(array(y_data[:,0]+1e-32)/(estimatey+1e-32)))
                        ratioerror=log(abs(array(y_data[:,1]-y_data[:,0]+1e-32)/array(y_data[:,1]-estimatey+1e-32)))  #加一个很小的数，避免出现零值
                        d1=array(y_data[:,0])*ratio
                        d2=array(y_data[:,1]-y_data[:,0])*ratioerror
                        c=d1+d2
                        d=2*sum(c,axis=0)
                if distr=="gama":
                        c=-log(array(y_data[:,0]+1e-32)/(estimatey+1e-32))+(array(y_data[:,0])-estimatey)/(estimatey+1e-32)
                        d=d=2*sum(c,axis=0)
                if distr=="poisson":
                        c=array(y_data[:,0])*log(array(y_data[:,0]+1e-32)/(estimatey+1e-32))-(array(y_data[:,0])-estimatey)
                        d=2*sum(c,axis=0)
                if distr=="igaussian":
                        c=power(array(y_data[:,0])-estimatey,2)/(power(estimatey,2)*array(y_data[:,0])+1e-32)
                        d=2*sum(c,axis=0)
                AIC=d+2*(numFeatures+1)
                #下面这段可能用diag函数效率更高
                temp=[]
                for i in range(numFeatures+1):
                        temp.append(sqrt(linalg.inv(mat(jo))[i,i]))
                zvalue=array(b)/array(mat(temp).T)
                pr=2*(1-norm.cdf(abs(mat(zvalue))))
                #title=['Estimate','Std. Error','z value','Pr(>|z|)']
                result=pd.DataFrame(column_stack((b,mat(temp).T,zvalue,pr)))
                result.rename(columns={0:'Estimate',1:'Std. Error',2:'z value',3:'Pr(>|z|)'}, inplace=True)
                aic=pd.DataFrame(column_stack((d,AIC)))
                #pandas默认会生成0，1，2...的名字，rename方法重命名
                aic.rename(columns={0:'Residual deviance',1:'AIC'}, inplace=True)
                #result=pd.DataFrame(row_stack((title,result)))
                return result,aic

