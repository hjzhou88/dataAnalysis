# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'filter.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_filter(object):
    def setupUi(self, filter):
        filter.setObjectName(_fromUtf8("filter"))
        filter.resize(264, 218)
        self.radioButton = QtGui.QRadioButton(filter)
        self.radioButton.setGeometry(QtCore.QRect(20, 60, 89, 16))
        self.radioButton.setObjectName(_fromUtf8("radioButton"))
        self.radioButton_2 = QtGui.QRadioButton(filter)
        self.radioButton_2.setGeometry(QtCore.QRect(20, 90, 89, 16))
        self.radioButton_2.setObjectName(_fromUtf8("radioButton_2"))
        self.radioButton_3 = QtGui.QRadioButton(filter)
        self.radioButton_3.setGeometry(QtCore.QRect(20, 120, 101, 16))
        self.radioButton_3.setObjectName(_fromUtf8("radioButton_3"))
        self.radioButton_4 = QtGui.QRadioButton(filter)
        self.radioButton_4.setGeometry(QtCore.QRect(20, 150, 101, 16))
        self.radioButton_4.setObjectName(_fromUtf8("radioButton_4"))
        self.groupBox = QtGui.QGroupBox(filter)
        self.groupBox.setGeometry(QtCore.QRect(10, 40, 241, 141))
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.lineEdit = QtGui.QLineEdit(self.groupBox)
        self.lineEdit.setGeometry(QtCore.QRect(130, 20, 91, 21))
        self.lineEdit.setObjectName(_fromUtf8("lineEdit"))
        self.lineEdit_2 = QtGui.QLineEdit(self.groupBox)
        self.lineEdit_2.setGeometry(QtCore.QRect(130, 50, 91, 21))
        self.lineEdit_2.setObjectName(_fromUtf8("lineEdit_2"))
        self.lineEdit_3 = QtGui.QLineEdit(self.groupBox)
        self.lineEdit_3.setGeometry(QtCore.QRect(130, 80, 91, 21))
        self.lineEdit_3.setObjectName(_fromUtf8("lineEdit_3"))
        self.lineEdit_4 = QtGui.QLineEdit(self.groupBox)
        self.lineEdit_4.setGeometry(QtCore.QRect(130, 110, 91, 21))
        self.lineEdit_4.setObjectName(_fromUtf8("lineEdit_4"))
        self.pushButton = QtGui.QPushButton(filter)
        self.pushButton.setGeometry(QtCore.QRect(20, 190, 75, 23))
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
        self.pushButton_2 = QtGui.QPushButton(filter)
        self.pushButton_2.setGeometry(QtCore.QRect(150, 190, 75, 23))
        self.pushButton_2.setObjectName(_fromUtf8("pushButton_2"))
        self.comboBox = QtGui.QComboBox(filter)
        self.comboBox.setGeometry(QtCore.QRect(30, 10, 211, 22))
        self.comboBox.setObjectName(_fromUtf8("comboBox"))
        self.groupBox.raise_()
        self.radioButton.raise_()
        self.radioButton_2.raise_()
        self.radioButton_3.raise_()
        self.radioButton_4.raise_()
        self.pushButton.raise_()
        self.pushButton_2.raise_()
        self.comboBox.raise_()

        self.retranslateUi(filter)
        QtCore.QObject.connect(self.pushButton_2, QtCore.SIGNAL(_fromUtf8("clicked()")), filter.close)
        QtCore.QMetaObject.connectSlotsByName(filter)

    def retranslateUi(self, filter):
        filter.setWindowTitle(_translate("filter", "filter", None))
        self.radioButton.setText(_translate("filter", "Not Equal", None))
        self.radioButton_2.setText(_translate("filter", "Equal", None))
        self.radioButton_3.setText(_translate("filter", "Greater Than", None))
        self.radioButton_4.setText(_translate("filter", "Smaller Than", None))
        self.groupBox.setTitle(_translate("filter", "Conditions", None))
        self.pushButton.setText(_translate("filter", "OK", None))
        self.pushButton_2.setText(_translate("filter", "CANCEL", None))

