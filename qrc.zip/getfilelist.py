import os

class getFileList():
    def GetFileList(self,dir,fileList):
        newDir = dir
        if os.path.isfile(dir):
            fileList.append(dir)
        elif os.path.isdir(dir):
            for s in os.listdir(dir):
                #�����Ҫ����ĳЩ�ļ��У�ʹ�����´���
                #if s == "xxx":
                #continue
                newDir=os.path.join(dir,s)
                GetFileList(newDir, fileList)
        return fileList 
