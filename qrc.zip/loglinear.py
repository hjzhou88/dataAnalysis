#coding=gbk

from numpy import *
import pandas as pd
from scipy.stats import norm


class loglinear(object):
    def sigmoid(self,x):
	u=1/(1+exp(-x))
	return u
    def logit(self,x_data,y_data):
	x_data=mat(x_data.astype(float))   #���⴫���������object��
	y_data=mat(y_data.astype(float))
	numSamples,numFeatures=x_data.shape
	add=ones((numSamples,1))
	x_tran=column_stack((add,x_data))
	b=zeros((numFeatures+1,1))
	u=zeros((numFeatures+1,1))
        jo=zeros((numFeatures+1,numFeatures+1))
        n,d=y_data.shape
        if d==1:
		y_data=column_stack((y_data,add))
	while True:
		temp_b=b
		output=self.sigmoid(mat(x_tran)*mat(temp_b))
		error=y_data[:,0]-array(y_data[:,1])*array(output)
		u=mat(x_tran).T*error
		byout=array(y_data[:,1])*array(output)*array(1-output) #��������˷���������
		out=byout*array(x_tran)
		jo=mat(x_tran).T*mat(out)
		b=temp_b+linalg.inv(mat(jo))*u
		if float((b-temp_b).T*(b-temp_b))<0.001:
			break
        output=self.sigmoid(mat(x_tran)*mat(b))
        estimatey=array(y_data[:,1])*array(output)
        ratio=log(array(y_data[:,0]+1e-32)/(estimatey+1e-32))
        ratioerror=log(array(y_data[:,1]-y_data[:,0]+1e-32)/array(y_data[:,1]-estimatey)+1e-32)  #��һ����С���������������ֵ
        d1=array(y_data[:,0])*ratio
        d2=array(y_data[:,1]-y_data[:,0])*ratioerror

	c=d1+d2
	d=2*sum(c,axis=0)
	AIC=d+2*(numFeatures+1)

        temp=[]
	for i in range(numFeatures+1):
		temp.append(sqrt(linalg.inv(mat(jo))[i,i]))
	zvalue=array(b)/array(mat(temp).T)
	pr=2*(1-norm.cdf(abs(mat(zvalue))))
	#title=['Estimate','Std. Error','z value','Pr(>|z|)']
	result=pd.DataFrame(column_stack((b,mat(temp).T,zvalue,pr)))
	result.rename(columns={0:'Estimate',1:'Std. Error',2:'z value',3:'Pr(>|z|)'}, inplace=True)
	aic=pd.DataFrame(column_stack((d,AIC)))
	aic.rename(columns={0:'Residual deviance',1:'AIC'}, inplace=True)
	#result=pd.DataFrame(row_stack((title,result)))
	return result,aic

    def nomlogit(self,x_data,y_data,lam):
	x_data=mat(x_data.astype(float))   #���⴫���������object��
	y_data=mat(y_data.astype(float))
	numSamples,numFeatures=x_data.shape
	add=ones((numSamples,1))
	x_tran=column_stack((add,x_data))
	#b=zeros((numFeatures+1,1))
	lamda=diag(diag(lam*ones((numFeatures+1,numFeatures+1))))
	u=zeros((numFeatures+1,1))
        jo=zeros((numFeatures+1,numFeatures+1))
        #n=sum(y_data,axis=0)
        n,d=y_data.shape
        b=mat(zeros((numFeatures+1,d-1)))
        error_b=mat(zeros((numFeatures+1,d-1)))
	while True:
		temp_b=b
		output=array(exp(mat(x_tran)*mat(temp_b)))/array(1+sum(exp(mat(x_tran)*mat(temp_b)),axis=1))
		error=y_data[:,0:(d-1)]-array(y_data[:,d-1])*array(output)
		u=mat(x_tran).T*error
		byout=mat(array(y_data[:,d-1])*array(output)*array(1-output)) #��������˷���������
		bb=array(temp_b)                                             #ת��������ֵ�������b��
		for i in range(d-1):
			out=array(byout[:,i])*array(x_tran)
			jo=mat(x_tran).T*mat(out)+lamda
			invjo=linalg.inv(mat(jo))
			b[:,i]=temp_b[:,i]+invjo*u[:,i]       #�������ֵҲ����ű�
			for j in range(numFeatures+1):
				error_b[j,i]=sqrt(invjo[j,j])

		dev=0
		bb=mat(bb)                                          #��������������㣬����;�����ȡֵ��һ��������ɺ����ֵ
		for i in range(d-1):
			dev=dev+float((b[:,i]-bb[:,i]).T*(b[:,i]-bb[:,i]))
		if dev<0.001:
			break
	zvalue=array(b)/array(error_b)
	pr=2*(1-norm.cdf(abs(mat(zvalue))))
	result=pd.DataFrame(column_stack((b,error_b,zvalue,pr)))
	n,p=b.shape
	nameList=[]
	for i in range(p):
            nameList.append('Estimate')
        for i in range(p):
            nameList.append('Std. Error')
        for i in range(p):
            nameList.append('z value')
        for i in range(p):
            nameList.append('Pr(>|z|)')
        result.columns=nameList
	#result.rename(columns={0:'Estimate',1:'Std. Error',2:'z value',3:'Pr(>|z|)'}, inplace=True)
	return result


    def plum(self,xdata,ydata):
	xdata=mat(xdata.astype(float))
	ydata=mat(ydata.astype(float))
	n,k=ydata.shape
	numSamples,numFeatures=xdata.shape
	nk=n*k
	nk1=nk-n
	addone=ones((numSamples,1))
	theta=eye(k-1)
	x0=array(n*list(theta))
	a=[1]*(k-1)  #����k-1��[1,1,...1]
	b=[0]*n*(k-1)
	c=array((a+b)*n)
	d=c[0:n*n*(k-1)]
	dupl=d.reshape(n,n*(k-1)).T
	x=column_stack((x0,mat(dupl)*xdata))
	z=cumsum(ydata,axis=1)
	zsum=sum(z,0)
	cot=zsum[:,0:(k-1)]/zsum[:,-1]
	ctot=log(array(cot)/array(1-cot))
	b=zeros((1,numFeatures))
	b=column_stack((ctot,b)).T
	m=mat(dupl)*mat(z[:,-1])
	a1=[1]*k
	b1=[0]*n*k
	c1=array((a1+b1)*n)
	d1=c1[0:n*n*(k)]
	dupl1=d1.reshape(n,n*(k)).T
	mk=array(mat(dupl1)*mat(z[:,-1])) #���͵�z[:,-1]�е�ÿ��ֵ����k��
	
	y=array(z[:,0:(k-1)]).ravel()
	diff=eye(k)
	a=arange(1,(n+1))*k-1
	for i in range(1,k):
		diff[i-1,i]=-1
	count=0
	while True:
		temp_b=b
		eta=array(mat(x)*mat(temp_b)).ravel()
		gamma=self.sigmoid(eta)
		cfit=array(m).ravel()*array(gamma)
		mgamma=column_stack((gamma.reshape(n,k-1),addone))
		pi=(array(mat(mgamma)*mat(diff))).ravel()
		fitted=matrix(mk*array(mat(pi).T)).reshape(n,k)
		tt=pd.DataFrame(ydata)
		tt=tt[tt>1]
		tt=tt.fillna(value=1)
		devmatrix=array(ydata)*log(array(tt)/array(fitted))
		dev=2*sum(sum(devmatrix,axis=0))
		print dev
		w=diag(1/pi+1/hstack((pi[1:nk],pi[0:1])))
		for i in range(1,nk):
			w[i-1,i]=-1/pi[i]
			w[i,i-1]=-1/pi[i]
		der=(array(gamma)*array(1-gamma)).ravel()
		w=delete(w,a,axis=0)
		w=delete(w,a,axis=1)
		w=mat(diag(der))*mat(w)*mat(diag(der))
		deriv=mat(x).T*mat(w)*mat((y-cfit)/der).T
		fi=mat(x).T*mat(array(m)*array(w))*mat(x)
		b=temp_b+linalg.inv(fi)*mat(deriv)
		count=count+1
		if float((b-temp_b).T*(b-temp_b))<0.0001:
			break
	AIC=dev+2*(numFeatures+1)
	error_b=diag(linalg.inv(fi))
	zvalue=array(b)/array(mat(error_b).T)
	pr=2*(1-norm.cdf(abs(mat(zvalue))))
	result=pd.DataFrame(column_stack((b,mat(error_b).T,zvalue,pr)))
	result.rename(columns={0:'Estimate',1:'Std. Error',2:'z value',3:'Pr(>|z|)'}, inplace=True)
	aic=pd.DataFrame(column_stack((dev,AIC)))
	aic.rename(columns={0:'Residual deviance',1:'AIC'}, inplace=True)
	return result,aic

