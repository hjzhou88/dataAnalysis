# coding: utf-8

from PyQt4.QtGui import *
from PyQt4.QtCore import *
import sys
import palettable.colorbrewer as cb
import palettable.tableau as tb
import palettable.wesanderson as wd


class staticsDialog(QDialog):
    def __init__(self,parent=None):
        super(staticsDialog,self).__init__(parent)
        self.setWindowTitle(self.tr("Statics"))
        gridLayout=QGridLayout()
        self.dataLabel=QLabel(self.tr("Data"))
        self.kindLabel=QLabel(self.tr('Kind'))
        self.styleLabel=QLabel(self.tr('Style'))
        self.showLabel=QLabel(self.tr('Show'))
        
        self.dataComb=QComboBox()
        self.kindComb=QComboBox()
        self.explodeComb=QComboBox()
        self.styleComb=QComboBox()
        self.showComb=QComboBox()
        
        self.showComb.addItem(self.tr("True"))
        self.showComb.addItem(self.tr("False"))
        self.styleComb.addItem(self.tr("None"))
        self.kindComb.addItem(self.tr("lag_plot"))
        self.kindComb.addItem(self.tr("autocorrelation_plot"))


        self.okButton=QPushButton(self.tr("OK"))
        self.cancelButton=QPushButton(self.tr("Cancel"))
        #cancelButton.clicked.connect(self.close())
        gridLayout.addWidget(self.dataLabel,0,0)
        gridLayout.addWidget(self.dataComb,0,1)
        gridLayout.addWidget(self.kindLabel,0,2)
        gridLayout.addWidget(self.kindComb,0,3)
        
        gridLayout.addWidget(self.styleLabel,1,0)
        gridLayout.addWidget(self.styleComb,1,1)
        gridLayout.addWidget(self.showLabel,1,2)
        gridLayout.addWidget(self.showComb,1,3)


        gridLayout2=QGridLayout()       
        self.okButton=QPushButton(self.tr("Yes"))
        cancelButton=QPushButton(self.tr("Cancel"))
        colorButton=QPushButton(self.tr("MoreColor"))
        #colorButton.clicked.connect(self.slotEx)
        self.connect(colorButton,SIGNAL("clicked()"),self.slotExtension)  #扩展信号
        btnBox=QDialogButtonBox(Qt.Horizontal)
        btnBox.addButton(self.okButton,QDialogButtonBox.ActionRole)
        btnBox.addButton(cancelButton,QDialogButtonBox.ActionRole)
        btnBox.addButton(colorButton,QDialogButtonBox.ActionRole)

        gridLayout2.addWidget(self.okButton,0,1)
        gridLayout2.addWidget(cancelButton,0,2)
        gridLayout2.addWidget(colorButton,0,3)

        self.detailWidget=QWidget()
        self.colorLayout=QGridLayout(self.detailWidget)
        hcolorLayout=QHBoxLayout()
        cycleColorLabel=QLabel(self.tr('ColorSet'))
        self.lineEdit_2=QLineEdit()
        hcolorLayout.addWidget(self.lineEdit_2)
        hcolorLayout.addWidget(cycleColorLabel)
        self.tree=QTreeWidget()
        self.tree.itemDoubleClicked.connect(self.TreeDBclick)
        #self.connect(self.tree,SIGNAL("itemDoubleClicked()"),self.TreeDBclick)  #双击信号
        self.tree.setColumnCount(1)
        self.tree.setHeaderLabels(['COLOR_MAPS'])
        palettable= QTreeWidgetItem(self.tree)
        palettable.setText(0,'palettable')
        colorbrewer=QTreeWidgetItem(palettable)
        colorbrewer.setText(0,'colorbrewer')
        diverging=QTreeWidgetItem(colorbrewer)
        diverging.setText(0,'diverging')
        divergingList=cb.COLOR_MAPS['Diverging'].keys()
        #print QualitativeList
        for i in divergingList:
            colorName=i
            colorName=QTreeWidgetItem(diverging)
            colorName.setText(0,i)
            listI=cb.COLOR_MAPS['Diverging'][i].keys()
            for j in listI:
                colorNumber1=QTreeWidgetItem(colorName)
                colorNumber1.setText(0,i+'_'+j)
                colorNumber2=QTreeWidgetItem(colorName)
                colorNumber2.setText(0,i+'_'+j+'_r')
        qualitative=QTreeWidgetItem(colorbrewer)
        qualitative.setText(0,'qualitative')
        QualitativeList=cb.COLOR_MAPS['Qualitative'].keys()
        #print QualitativeList
        for i in QualitativeList:
            colorName=i
            colorName=QTreeWidgetItem(qualitative)
            colorName.setText(0,i)
            listI=cb.COLOR_MAPS['Qualitative'][i].keys()
            for j in listI:
                colorNumber1=QTreeWidgetItem(colorName)
                colorNumber1.setText(0,i+'_'+j)
                colorNumber2=QTreeWidgetItem(colorName)
                colorNumber2.setText(0,i+'_'+j+'_r')
                
        sequential=QTreeWidgetItem(colorbrewer)
        sequential.setText(0,'sequential')
        sequentialList=cb.COLOR_MAPS['Sequential'].keys()
        #print QualitativeList
        for i in sequentialList:
            colorName=i
            colorName=QTreeWidgetItem(sequential)
            colorName.setText(0,i)
            listI=cb.COLOR_MAPS['Sequential'][i].keys()
            for j in listI:
                colorNumber1=QTreeWidgetItem(colorName)
                colorNumber1.setText(0,i+'_'+j)
                colorNumber2=QTreeWidgetItem(colorName)
                colorNumber2.setText(0,i+'_'+j+'_r')
        
        tableau=QTreeWidgetItem(palettable)
        tableau.setText(0,'tableau')
        qualitative=QTreeWidgetItem(tableau)
        qualitative.setText(0,'qualitative')
        colorList=tb.tableau.palette_names
        for i in colorList:
            colorName1=i
            colorName1=QTreeWidgetItem(qualitative)
            colorName1.setText(0,i)
            colorName2=i
            colorName2=QTreeWidgetItem(qualitative)
            colorName2.setText(0,i+'_r')
        wesanderson=QTreeWidgetItem(palettable)
        wesanderson.setText(0,'wesanderson')
        qualitative=QTreeWidgetItem(wesanderson)
        qualitative.setText(0,'qualitative')
        colorList=wd.wesanderson._get_all_maps().keys()
        for i in colorList:
            colorName=i
            colorName=QTreeWidgetItem(qualitative)
            colorName.setText(0,i)
        self.colorLayout.addLayout(hcolorLayout,0,0)
        self.colorLayout.addWidget(self.tree,1,0)

        self.detailWidget.hide()  #先隐藏

        mainLayout=QVBoxLayout()
        mainLayout.addLayout(gridLayout)
        mainLayout.addLayout(gridLayout2)
        mainLayout.addWidget(self.detailWidget)
        mainLayout.setSizeConstraint(QLayout.SetFixedSize)
        mainLayout.setSpacing(10)
        self.setLayout(mainLayout)   #此句加上方可显示Layout里的内容

    def slotExtension(self):
        if self.detailWidget.isHidden():
            self.detailWidget.show()
        else:
            self.detailWidget.hide()

        #def slotExtension(self):  #对齐方式不对
            #if self.detailWidget.isHidden():
                #self.detailWidget.show()
            #else:
                #self.detailWidget.hide()
    def TreeDBclick(self):
        if unicode(self.tree.currentItem().parent().text(self.tree.currentColumn()))!='qualitative':
            PColorItem=unicode(self.tree.currentItem().parent().parent().text(self.tree.currentColumn()))+"."  #text里面带列号才能获得文本
        else:
            PColorItem=""
        colorItem=unicode(self.tree.currentItem().text(self.tree.currentColumn()))
        self.lineEdit_2.setText(PColorItem+colorItem)
    

#app=QApplication(sys.argv)  
#main=pieDialog()  
#main.show()  
#app.exec_() 
