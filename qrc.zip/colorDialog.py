import sys
from PyQt4.QtGui import *
from PyQt4.QtCore import *
import palettable.colorbrewer as cb
class TreeWidget(QMainWindow):
    def __init__(self,parent=None):
        super(TreeWidget,self).__init__(parent)
        self.tree=QTreeWidget()
        self.tree.setColumnCount(2)
        self.tree.setHeaderLabels(['COLOR_MAPS','Color'])
        palettable= QTreeWidgetItem(self.tree)
        palettable.setText(0,'palettable')
        colorbrewer=QTreeWidgetItem(palettable)
        colorbrewer.setText(0,'colorbrewer')
        diverging=QTreeWidgetItem(colorbrewer)
        diverging.setText(0,'diverging')
        divergingList=cb.COLOR_MAPS['Diverging'].keys()
        #print QualitativeList
        for i in divergingList:
            colorName=i
            colorName=QTreeWidgetItem(diverging)
            colorName.setText(0,i)
            listI=cb.COLOR_MAPS['Diverging'][i].keys()
            for j in listI:
                colorNumber1=QTreeWidgetItem(colorName)
                colorNumber1.setText(0,i+'_'+j)
                colorNumber2=QTreeWidgetItem(colorName)
                colorNumber2.setText(0,i+'_'+j+'_r')
        qualitative=QTreeWidgetItem(colorbrewer)
        qualitative.setText(0,'qualitative')
        QualitativeList=cb.COLOR_MAPS['Qualitative'].keys()
        #print QualitativeList
        for i in QualitativeList:
            colorName=i
            colorName=QTreeWidgetItem(qualitative)
            colorName.setText(0,i)
            listI=cb.COLOR_MAPS['Qualitative'][i].keys()
            for j in listI:
                colorNumber1=QTreeWidgetItem(colorName)
                colorNumber1.setText(0,i+'_'+j)
                colorNumber2=QTreeWidgetItem(colorName)
                colorNumber2.setText(0,i+'_'+j+'_r')
                
        sequential=QTreeWidgetItem(colorbrewer)
        sequential.setText(0,'sequential')
        sequentialList=cb.COLOR_MAPS['Sequential'].keys()
        #print QualitativeList
        for i in sequentialList:
            colorName=i
            colorName=QTreeWidgetItem(sequential)
            colorName.setText(0,i)
            listI=cb.COLOR_MAPS['Sequential'][i].keys()
            for j in listI:
                colorNumber1=QTreeWidgetItem(colorName)
                colorNumber1.setText(0,i+'_'+j)
                colorNumber2=QTreeWidgetItem(colorName)
                colorNumber2.setText(0,i+'_'+j+'_r')
        
        tableau=QTreeWidgetItem(palettable)
        tableau.setText(0,'tableau')
        wesanderson=QTreeWidgetItem(palettable)
        wesanderson.setText(0,'wesanderson')
        self.tree.addTopLevelItem(palettable)
        self.setCentralWidget(self.tree)
app = QApplication(sys.argv)
tp = TreeWidget()
tp.show()
app.exec_()
