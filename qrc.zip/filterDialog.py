# -*- coding: utf-8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
import sys
import os
from filter import Ui_filter


class filterDialog(QDialog,Ui_filter):
    def __init__(self,parent=None):
        super(filterDialog,self).__init__(parent)
        self.setupUi(self)
        

    
