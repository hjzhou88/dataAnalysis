# coding:utf-8
from numpy import *


class SVM:
    def __init__(self,x,y,c=5,tol=0.01,kernel=Linear_kernel):
        self.x=array(x)
        self.y=array(y)
        self.tol=tol
        self.c=c
        self.kernel=kernel

    def fitKKT(self,i):
        
