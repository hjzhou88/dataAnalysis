# coding:utf-8

from numpy import *


class PCA():
        def pcapercent(self,dataSet):
                #dataSet=mat(dataSet)
                meanVals=mean(dataSet,axis=0)#对列求均值
                #meanVals=dataSet.mean()
                meanZeros=dataSet-meanVals
                covVals=cov(meanZeros,rowvar=0)#0表示一行是一个样本，1表示一列是一个样本
                eigVals,eigVectors=linalg.eig(mat(covVals))
                eigSort=sort(eigVals)
                eigSort=eigSort[-1::-1]#python里面，list[a:b:c]代表从下标a开始到b，步长为c
                eigSum=sum(eigSort)
                return eigSort/eigSum

        def pca(self,dataSet,n):
                meanVals=mean(dataSet,axis=0)#对列求均值
                meanZeros=dataSet-meanVals
                covVals=cov(meanZeros,rowvar=0)#0表示一行是一个样本，1表示一列是一个样本
                eigVals,eigVectors=linalg.eig(mat(covVals))
                eigIndex=argsort(eigVals)
                n_eigIndex=eigIndex[-1:-(n+1):-1]
                n_eigVectors=eigVectors[:,n_eigIndex]
                lowData=mat(meanZeros)*mat(n_eigVectors)#array，matrix乘积结果不一样，数组的dot相当于矩阵的*
                reconData=mat(lowData)*mat(n_eigVectors.T)+mat(meanVals)#必须转化成矩阵，否则结果出现错误，mean对data.frme，array，matrix都可计算，data.frme类型时可能含标题，使用mat可去掉data.frme类型的标题
                return lowData,reconData

