# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'PCALD.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(403, 300)
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setGeometry(QtCore.QRect(230, 10, 161, 251))
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.label = QtGui.QLabel(self.groupBox)
        self.label.setGeometry(QtCore.QRect(10, 160, 71, 16))
        self.label.setObjectName(_fromUtf8("label"))
        self.label_2 = QtGui.QLabel(self.groupBox)
        self.label_2.setGeometry(QtCore.QRect(10, 20, 54, 12))
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.listWidget_2 = QtGui.QListWidget(self.groupBox)
        self.listWidget_2.setGeometry(QtCore.QRect(10, 40, 141, 111))
        self.listWidget_2.setObjectName(_fromUtf8("listWidget_2"))
        self.pushButton_8 = QtGui.QPushButton(self.groupBox)
        self.pushButton_8.setGeometry(QtCore.QRect(100, 10, 41, 23))
        self.pushButton_8.setObjectName(_fromUtf8("pushButton_8"))
        self.lineEdit = QtGui.QLineEdit(self.groupBox)
        self.lineEdit.setGeometry(QtCore.QRect(80, 160, 71, 20))
        self.lineEdit.setObjectName(_fromUtf8("lineEdit"))
        self.checkBox = QtGui.QCheckBox(self.groupBox)
        self.checkBox.setGeometry(QtCore.QRect(10, 190, 141, 16))
        self.checkBox.setObjectName(_fromUtf8("checkBox"))
        self.checkBox_2 = QtGui.QCheckBox(self.groupBox)
        self.checkBox_2.setGeometry(QtCore.QRect(10, 220, 141, 16))
        self.checkBox_2.setObjectName(_fromUtf8("checkBox_2"))
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setGeometry(QtCore.QRect(10, 10, 161, 251))
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.listWidget = QtGui.QListWidget(self.groupBox_2)
        self.listWidget.setGeometry(QtCore.QRect(10, 20, 141, 221))
        self.listWidget.setObjectName(_fromUtf8("listWidget"))
        self.pushButton = QtGui.QPushButton(Dialog)
        self.pushButton.setGeometry(QtCore.QRect(50, 270, 75, 23))
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
        self.pushButton_2 = QtGui.QPushButton(Dialog)
        self.pushButton_2.setGeometry(QtCore.QRect(270, 270, 75, 23))
        self.pushButton_2.setObjectName(_fromUtf8("pushButton_2"))
        self.pushButton_3 = QtGui.QPushButton(Dialog)
        self.pushButton_3.setGeometry(QtCore.QRect(180, 70, 41, 23))
        self.pushButton_3.setObjectName(_fromUtf8("pushButton_3"))
        self.pushButton_4 = QtGui.QPushButton(Dialog)
        self.pushButton_4.setGeometry(QtCore.QRect(180, 120, 41, 23))
        self.pushButton_4.setObjectName(_fromUtf8("pushButton_4"))
        self.groupBox_2.raise_()
        self.pushButton.raise_()
        self.pushButton_2.raise_()
        self.pushButton_3.raise_()
        self.pushButton_4.raise_()
        self.groupBox.raise_()

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "Dialog", None))
        self.groupBox.setTitle(_translate("Dialog", "Selection", None))
        self.label.setText(_translate("Dialog", "PC Number:", None))
        self.label_2.setText(_translate("Dialog", "DataSet", None))
        self.pushButton_8.setText(_translate("Dialog", "Next", None))
        self.checkBox.setText(_translate("Dialog", "Low Dimention Data", None))
        self.checkBox_2.setText(_translate("Dialog", "Reconstructed Data", None))
        self.groupBox_2.setTitle(_translate("Dialog", "Variable", None))
        self.pushButton.setText(_translate("Dialog", "Yes", None))
        self.pushButton_2.setText(_translate("Dialog", "Cancel", None))
        self.pushButton_3.setText(_translate("Dialog", ">>", None))
        self.pushButton_4.setText(_translate("Dialog", "<<", None))

