from PyQt4.QtCore import *
from PyQt4.QtGui import *
import sys
from LD import Ui_Dialog


class learDialog(QDialog,Ui_Dialog):
    def __init__(self,parent=None):
        super(learDialog,self).__init__(parent)
        self.setupUi(self)
        self.pushButton_3.clicked.connect(self.B3click)
        self.pushButton_4.clicked.connect(self.B4click)
        self.pushButton_5.clicked.connect(self.B5click)
        self.pushButton_6.clicked.connect(self.B6click)
        self.pushButton_2.clicked.connect(self.B2click)
        self.pushButton_7.clicked.connect(self.B7click)
        self.pushButton_8.clicked.connect(self.B8click)

    def B3click(self):
        index=self.listWidget.currentRow()
        self.listWidget_2.insertItem(index,self.listWidget.takeItem(index))

    def B4click(self):
        index=self.listWidget_2.currentRow()
        self.listWidget.insertItem(index,self.listWidget_2.takeItem(index))

    def B5click(self):
        index=self.listWidget_3.currentRow()
        self.listWidget.insertItem(index,self.listWidget_3.takeItem(index))

    def B6click(self):
        index=self.listWidget.currentRow()
        self.listWidget_3.insertItem(index,self.listWidget.takeItem(index))

    def B2click(self):
        self.close()

    def B7click(self):
        if self.listWidget_3.currentRow()==self.listWidget_3.count()-1:
            currentItem=self.listWidget_3.item(self.listWidget_3.currentRow()).text()
            nextItem=self.listWidget_3.item(0).text()
            self.listWidget_3.item(self.listWidget_3.currentRow()).setText(nextItem)
            self.listWidget_3.item(0).setText(currentItem)
        else:
            currentItem=self.listWidget_3.item(self.listWidget_3.currentRow()).text()
            nextItem=self.listWidget_3.item(self.listWidget_3.currentRow()+1).text()
            self.listWidget_3.item(self.listWidget_3.currentRow()).setText(nextItem)
            self.listWidget_3.item(self.listWidget_3.currentRow()+1).setText(currentItem)

    def B8click(self):
        if self.listWidget_2.currentRow()==self.listWidget_2.count()-1:
            currentItem=self.listWidget_2.item(self.listWidget_2.currentRow()).text()
            nextItem=self.listWidget_2.item(0).text()
            self.listWidget_2.item(self.listWidget_2.currentRow()).setText(nextItem)
            self.listWidget_2.item(0).setText(currentItem)

        else:
            currentItem=self.listWidget_2.item(self.listWidget_2.currentRow()).text()
            nextItem=self.listWidget_2.item(self.listWidget_2.currentRow()+1).text()
            self.listWidget_2.item(self.listWidget_2.currentRow()).setText(nextItem)
            self.listWidget_2.item(self.listWidget_2.currentRow()+1).setText(currentItem)


        

