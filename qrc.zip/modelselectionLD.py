# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'modelselectionLD.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName(_fromUtf8("Dialog"))
        Dialog.resize(403, 300)
        self.groupBox = QtGui.QGroupBox(Dialog)
        self.groupBox.setGeometry(QtCore.QRect(230, 10, 161, 251))
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.label = QtGui.QLabel(self.groupBox)
        self.label.setGeometry(QtCore.QRect(10, 110, 54, 12))
        self.label.setObjectName(_fromUtf8("label"))
        self.label_2 = QtGui.QLabel(self.groupBox)
        self.label_2.setGeometry(QtCore.QRect(10, 20, 54, 12))
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.listWidget_3 = QtGui.QListWidget(self.groupBox)
        self.listWidget_3.setGeometry(QtCore.QRect(10, 130, 141, 81))
        self.listWidget_3.setObjectName(_fromUtf8("listWidget_3"))
        self.listWidget_2 = QtGui.QListWidget(self.groupBox)
        self.listWidget_2.setGeometry(QtCore.QRect(10, 40, 141, 51))
        self.listWidget_2.setObjectName(_fromUtf8("listWidget_2"))
        self.pushButton_7 = QtGui.QPushButton(self.groupBox)
        self.pushButton_7.setGeometry(QtCore.QRect(100, 100, 41, 23))
        self.pushButton_7.setObjectName(_fromUtf8("pushButton_7"))
        self.pushButton_8 = QtGui.QPushButton(self.groupBox)
        self.pushButton_8.setGeometry(QtCore.QRect(100, 10, 41, 23))
        self.pushButton_8.setObjectName(_fromUtf8("pushButton_8"))
        self.lineEdit = QtGui.QLineEdit(self.groupBox)
        self.lineEdit.setGeometry(QtCore.QRect(10, 220, 31, 20))
        self.lineEdit.setObjectName(_fromUtf8("lineEdit"))
        self.label_4 = QtGui.QLabel(self.groupBox)
        self.label_4.setGeometry(QtCore.QRect(40, 220, 21, 16))
        self.label_4.setObjectName(_fromUtf8("label_4"))
        self.lineEdit_3 = QtGui.QLineEdit(self.groupBox)
        self.lineEdit_3.setGeometry(QtCore.QRect(60, 220, 31, 20))
        self.lineEdit_3.setObjectName(_fromUtf8("lineEdit_3"))
        self.label_9 = QtGui.QLabel(self.groupBox)
        self.label_9.setGeometry(QtCore.QRect(100, 220, 21, 16))
        self.label_9.setObjectName(_fromUtf8("label_9"))
        self.lineEdit_4 = QtGui.QLineEdit(self.groupBox)
        self.lineEdit_4.setGeometry(QtCore.QRect(120, 220, 31, 20))
        self.lineEdit_4.setObjectName(_fromUtf8("lineEdit_4"))
        self.groupBox_2 = QtGui.QGroupBox(Dialog)
        self.groupBox_2.setGeometry(QtCore.QRect(10, 10, 161, 251))
        self.groupBox_2.setObjectName(_fromUtf8("groupBox_2"))
        self.listWidget = QtGui.QListWidget(self.groupBox_2)
        self.listWidget.setGeometry(QtCore.QRect(10, 20, 141, 221))
        self.listWidget.setObjectName(_fromUtf8("listWidget"))
        self.pushButton = QtGui.QPushButton(Dialog)
        self.pushButton.setGeometry(QtCore.QRect(50, 270, 75, 23))
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
        self.pushButton_2 = QtGui.QPushButton(Dialog)
        self.pushButton_2.setGeometry(QtCore.QRect(270, 270, 75, 23))
        self.pushButton_2.setObjectName(_fromUtf8("pushButton_2"))
        self.pushButton_3 = QtGui.QPushButton(Dialog)
        self.pushButton_3.setGeometry(QtCore.QRect(180, 50, 41, 23))
        self.pushButton_3.setObjectName(_fromUtf8("pushButton_3"))
        self.pushButton_4 = QtGui.QPushButton(Dialog)
        self.pushButton_4.setGeometry(QtCore.QRect(180, 80, 41, 23))
        self.pushButton_4.setObjectName(_fromUtf8("pushButton_4"))
        self.pushButton_5 = QtGui.QPushButton(Dialog)
        self.pushButton_5.setGeometry(QtCore.QRect(180, 180, 41, 23))
        self.pushButton_5.setObjectName(_fromUtf8("pushButton_5"))
        self.pushButton_6 = QtGui.QPushButton(Dialog)
        self.pushButton_6.setGeometry(QtCore.QRect(180, 150, 41, 23))
        self.pushButton_6.setObjectName(_fromUtf8("pushButton_6"))
        self.label_3 = QtGui.QLabel(Dialog)
        self.label_3.setGeometry(QtCore.QRect(190, 230, 54, 12))
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.groupBox_2.raise_()
        self.pushButton.raise_()
        self.pushButton_2.raise_()
        self.pushButton_3.raise_()
        self.pushButton_4.raise_()
        self.pushButton_5.raise_()
        self.pushButton_6.raise_()
        self.groupBox.raise_()
        self.label_3.raise_()

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        Dialog.setWindowTitle(_translate("Dialog", "Dialog", None))
        self.groupBox.setTitle(_translate("Dialog", "Selection", None))
        self.label.setText(_translate("Dialog", "Indenpend", None))
        self.label_2.setText(_translate("Dialog", "Denpend", None))
        self.pushButton_7.setText(_translate("Dialog", "Next", None))
        self.pushButton_8.setText(_translate("Dialog", "Next", None))
        self.lineEdit.setText(_translate("Dialog", "0.1", None))
        self.label_4.setText(_translate("Dialog", "to", None))
        self.lineEdit_3.setText(_translate("Dialog", "10", None))
        self.label_9.setText(_translate("Dialog", "by", None))
        self.lineEdit_4.setText(_translate("Dialog", "0.01", None))
        self.groupBox_2.setTitle(_translate("Dialog", "Variable", None))
        self.pushButton.setText(_translate("Dialog", "Yes", None))
        self.pushButton_2.setText(_translate("Dialog", "Cancel", None))
        self.pushButton_3.setText(_translate("Dialog", ">>", None))
        self.pushButton_4.setText(_translate("Dialog", "<<", None))
        self.pushButton_5.setText(_translate("Dialog", "<<", None))
        self.pushButton_6.setText(_translate("Dialog", ">>", None))
        self.label_3.setText(_translate("Dialog", "Lamda:", None))

