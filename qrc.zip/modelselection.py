# coding:utf-8


from numpy import *

class selection(object):
    def rige(self,xdata,ydata,lamda):
        matxdata=mat(xdata.astype(float))
        matydata=mat(ydata.astype(float))
        beta=linalg.inv(matxdata.T*matxdata+lamda)*matxdata.T*matydata
        return beta
        
        
