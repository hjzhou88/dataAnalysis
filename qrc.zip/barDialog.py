# -*- coding: utf-8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
import sys
import os
import palettable.colorbrewer as cb
import palettable.tableau as tb
import palettable.wesanderson as wd
from bar import Ui_bar


class barDialog(QDialog,Ui_bar):
    def __init__(self,parent=None):
        super(barDialog,self).__init__(parent)
        self.setupUi(self)
        self.tree.setColumnCount(1)
        self.tree.setHeaderLabels(['COLOR_MAPS'])
        palettable= QTreeWidgetItem(self.tree)
        palettable.setText(0,'palettable')
        colorbrewer=QTreeWidgetItem(palettable)
        colorbrewer.setText(0,'colorbrewer')
        diverging=QTreeWidgetItem(colorbrewer)
        diverging.setText(0,'diverging')
        divergingList=cb.COLOR_MAPS['Diverging'].keys()
        #print QualitativeList
        for i in divergingList:
            colorName=i
            colorName=QTreeWidgetItem(diverging)
            colorName.setText(0,i)
            listI=cb.COLOR_MAPS['Diverging'][i].keys()
            for j in listI:
                colorNumber1=QTreeWidgetItem(colorName)
                colorNumber1.setText(0,i+'_'+j)
                colorNumber2=QTreeWidgetItem(colorName)
                colorNumber2.setText(0,i+'_'+j+'_r')
        qualitative=QTreeWidgetItem(colorbrewer)
        qualitative.setText(0,'qualitative')
        QualitativeList=cb.COLOR_MAPS['Qualitative'].keys()
        #print QualitativeList
        for i in QualitativeList:
            colorName=i
            colorName=QTreeWidgetItem(qualitative)
            colorName.setText(0,i)
            listI=cb.COLOR_MAPS['Qualitative'][i].keys()
            for j in listI:
                colorNumber1=QTreeWidgetItem(colorName)
                colorNumber1.setText(0,i+'_'+j)
                colorNumber2=QTreeWidgetItem(colorName)
                colorNumber2.setText(0,i+'_'+j+'_r')
                
        sequential=QTreeWidgetItem(colorbrewer)
        sequential.setText(0,'sequential')
        sequentialList=cb.COLOR_MAPS['Sequential'].keys()
        #print QualitativeList
        for i in sequentialList:
            colorName=i
            colorName=QTreeWidgetItem(sequential)
            colorName.setText(0,i)
            listI=cb.COLOR_MAPS['Sequential'][i].keys()
            for j in listI:
                colorNumber1=QTreeWidgetItem(colorName)
                colorNumber1.setText(0,i+'_'+j)
                colorNumber2=QTreeWidgetItem(colorName)
                colorNumber2.setText(0,i+'_'+j+'_r')
        
        tableau=QTreeWidgetItem(palettable)
        tableau.setText(0,'tableau')
        qualitative=QTreeWidgetItem(tableau)
        qualitative.setText(0,'qualitative')
        colorList=tb.tableau.palette_names
        for i in colorList:
            colorName1=i
            colorName1=QTreeWidgetItem(qualitative)
            colorName1.setText(0,i)
            colorName2=i
            colorName2=QTreeWidgetItem(qualitative)
            colorName2.setText(0,i+'_r')
        wesanderson=QTreeWidgetItem(palettable)
        wesanderson.setText(0,'wesanderson')
        qualitative=QTreeWidgetItem(wesanderson)
        qualitative.setText(0,'qualitative')
        colorList=wd.wesanderson._get_all_maps().keys()
        for i in colorList:
            colorName=i
            colorName=QTreeWidgetItem(qualitative)
            colorName.setText(0,i)
        #baseLayout=QGridLayout()
        #cverticalLayout=QVBoxLayout()
        #cverticalLayout.addLayout(self.verticalLayout)
        #cverticalLayout.addLayout(self.verticalLayout_2)
        #topLayout=QHBoxLayout()
        #topLayout.addLayout(self.gridLayout)
        #topLayout.addLayout(cverticalLayout)
        #topLayout.addLayout(self.gridLayout_2)

        #self.detailWidget=QWidget()
        
        #detailLayout=QHBoxLayout(self.detailWidget)
        #cverticalLayout_2=QVBoxLayout()
        #cverticalLayout_2.addLayout(self.verticalLayout_3)
        #cverticalLayout_2.addLayout(self.verticalLayout_4)
        #detailLayout.addLayout(self.gridLayout_4)
        #detailLayout.addLayout(cverticalLayout_2)
        #detailLayout.addLayout(self.gridLayout_3)
        #self.detailWidget.hide()
        
        #mainLayout=QVBoxLayout()
        #mainLayout.addLayout(topLayout)
        #mainLayout.addLayout(self.horizontalLayout)
        #mainLayout.addWidget(self.detailWidget)
        #mainLayout.setSizeConstraint(QLayout.SetFixedSize)
#这个设置保证了对话框的尺寸保持相对固定，始终是各控件组合的默认尺寸，
#在扩展部分显示时，对话框尺寸根据需显示的控件进行扩展调整，
#而在扩展部分隐藏时，对话框尺寸又恢复至初始状态。
        #mainLayout.setSpacing(10)
        #self.setLayout(mainLayout)
        
        #self.pushButton_.clicked.connect(self.B9click)
        self.pushButton_3.clicked.connect(self.B3click)
        self.pushButton_4.clicked.connect(self.B4click)
        self.pushButton_5.clicked.connect(self.B5click)
        self.pushButton_6.clicked.connect(self.B6click)
        self.pushButton_2.clicked.connect(self.B2click)
        self.tree.itemDoubleClicked.connect(self.TreeDBclick)
        #self.pushButton_7.clicked.connect(self.B7click)
        #self.pushButton_8.clicked.connect(self.B8click)
        self.listWidget.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.listWidget_2.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.listWidget_3.setSelectionMode(QAbstractItemView.ExtendedSelection)

    def TreeDBclick(self):
        if unicode(self.tree.currentItem().parent().text(self.tree.currentColumn()))!='qualitative':
            PColorItem=unicode(self.tree.currentItem().parent().parent().text(self.tree.currentColumn()))+"."  #text里面带列号才能获得文本
        else:
            PColorItem=""
        colorItem=unicode(self.tree.currentItem().text(self.tree.currentColumn()))
        self.lineEdit_2.setText(PColorItem+colorItem)

    def B3click(self):
        itemlist=self.listWidget.selectedItems()  #此种方法顺序一致
        for i in itemlist:
            self.listWidget.takeItem(self.listWidget.row(i))  #row获得ITEM行号
            self.listWidget_2.addItem(i)
    def B4click(self):
        itemlist=self.listWidget_2.selectedItems()
        for i in itemlist:
            self.listWidget_2.takeItem(self.listWidget_2.row(i))  #row获得ITEM行号
            self.listWidget.addItem(i)

    def B5click(self):
        #index=self.listWidget_3.currentRow()
        #self.listWidget.insertItem(index,self.listWidget_3.takeItem(index))
        itemlist=self.listWidget_3.selectedItems()
        for i in itemlist:
            self.listWidget_3.takeItem(self.listWidget_2.row(i))  #row获得ITEM行号
            self.listWidget.addItem(i)

    def B6click(self):
        itemlist=self.listWidget.selectedItems()  #此种方法顺序一致
        for i in itemlist:
            self.listWidget.takeItem(self.listWidget.row(i))  #row获得ITEM行号
            self.listWidget_3.addItem(i)

    def B2click(self):
        self.close()

    def B7click(self):
        if self.listWidget_3.currentRow()==self.listWidget_3.count()-1:
            currentItem=self.listWidget_3.item(self.listWidget_3.currentRow()).text()
            nextItem=self.listWidget_3.item(0).text()
            self.listWidget_3.item(self.listWidget_3.currentRow()).setText(nextItem)
            self.listWidget_3.item(0).setText(currentItem)
        else:
            currentItem=self.listWidget_3.item(self.listWidget_3.currentRow()).text()
            nextItem=self.listWidget_3.item(self.listWidget_3.currentRow()+1).text()
            self.listWidget_3.item(self.listWidget_3.currentRow()).setText(nextItem)
            self.listWidget_3.item(self.listWidget_3.currentRow()+1).setText(currentItem)

    def B8click(self):
        if self.listWidget_2.currentRow()==self.listWidget_2.count()-1:
            currentItem=self.listWidget_2.item(self.listWidget_2.currentRow()).text()
            nextItem=self.listWidget_2.item(0).text()
            self.listWidget_2.item(self.listWidget_2.currentRow()).setText(nextItem)
            self.listWidget_2.item(0).setText(currentItem)

        else:
            currentItem=self.listWidget_2.item(self.listWidget_2.currentRow()).text()
            nextItem=self.listWidget_2.item(self.listWidget_2.currentRow()+1).text()
            self.listWidget_2.item(self.listWidget_2.currentRow()).setText(nextItem)
            self.listWidget_2.item(self.listWidget_2.currentRow()+1).setText(currentItem)



    

    def B9click(self):
        if self.detailWidget.isHidden():
            self.detailWidget.show()  
        else:  
            self.detailWidget.hide()  
        

    
