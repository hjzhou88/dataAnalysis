# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'merge.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_merge(object):
    def setupUi(self, merge):
        merge.setObjectName(_fromUtf8("merge"))
        merge.resize(446, 240)
        self.listWidget = QtGui.QListWidget(merge)
        self.listWidget.setGeometry(QtCore.QRect(10, 40, 191, 191))
        self.listWidget.setObjectName(_fromUtf8("listWidget"))
        self.lineEdit = QtGui.QLineEdit(merge)
        self.lineEdit.setGeometry(QtCore.QRect(10, 10, 113, 20))
        self.lineEdit.setObjectName(_fromUtf8("lineEdit"))
        self.pushButton = QtGui.QPushButton(merge)
        self.pushButton.setGeometry(QtCore.QRect(130, 10, 75, 23))
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
        self.groupBox = QtGui.QGroupBox(merge)
        self.groupBox.setGeometry(QtCore.QRect(250, 20, 181, 181))
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.listWidget_2 = QtGui.QListWidget(self.groupBox)
        self.listWidget_2.setGeometry(QtCore.QRect(10, 20, 161, 91))
        self.listWidget_2.setObjectName(_fromUtf8("listWidget_2"))
        self.label = QtGui.QLabel(self.groupBox)
        self.label.setGeometry(QtCore.QRect(20, 120, 54, 16))
        self.label.setObjectName(_fromUtf8("label"))
        self.comboBox = QtGui.QComboBox(self.groupBox)
        self.comboBox.setGeometry(QtCore.QRect(90, 120, 81, 22))
        self.comboBox.setObjectName(_fromUtf8("comboBox"))
        self.comboBox.addItem(_fromUtf8(""))
        self.comboBox.addItem(_fromUtf8(""))
        self.comboBox.addItem(_fromUtf8(""))
        self.comboBox.addItem(_fromUtf8(""))
        self.label_2 = QtGui.QLabel(self.groupBox)
        self.label_2.setGeometry(QtCore.QRect(20, 150, 54, 16))
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.lineEdit_2 = QtGui.QLineEdit(self.groupBox)
        self.lineEdit_2.setGeometry(QtCore.QRect(90, 150, 81, 20))
        self.lineEdit_2.setObjectName(_fromUtf8("lineEdit_2"))
        self.listWidget_2.raise_()
        self.label.raise_()
        self.comboBox.raise_()
        self.label_2.raise_()
        self.lineEdit_2.raise_()
        self.pushButton_2 = QtGui.QPushButton(merge)
        self.pushButton_2.setGeometry(QtCore.QRect(250, 210, 75, 23))
        self.pushButton_2.setObjectName(_fromUtf8("pushButton_2"))
        self.pushButton_3 = QtGui.QPushButton(merge)
        self.pushButton_3.setGeometry(QtCore.QRect(340, 210, 75, 23))
        self.pushButton_3.setObjectName(_fromUtf8("pushButton_3"))
        self.pushButton_4 = QtGui.QPushButton(merge)
        self.pushButton_4.setGeometry(QtCore.QRect(210, 50, 31, 31))
        self.pushButton_4.setObjectName(_fromUtf8("pushButton_4"))
        self.pushButton_5 = QtGui.QPushButton(merge)
        self.pushButton_5.setGeometry(QtCore.QRect(210, 100, 31, 31))
        self.pushButton_5.setObjectName(_fromUtf8("pushButton_5"))

        self.retranslateUi(merge)
        QtCore.QObject.connect(self.pushButton_3, QtCore.SIGNAL(_fromUtf8("clicked()")), merge.close)
        QtCore.QMetaObject.connectSlotsByName(merge)

    def retranslateUi(self, merge):
        merge.setWindowTitle(_translate("merge", "merge", None))
        self.pushButton.setText(_translate("merge", "Change Path", None))
        self.groupBox.setTitle(_translate("merge", "Merge File Selection", None))
        self.label.setText(_translate("merge", "How", None))
        self.comboBox.setItemText(0, _translate("merge", "inner", None))
        self.comboBox.setItemText(1, _translate("merge", "outer", None))
        self.comboBox.setItemText(2, _translate("merge", "left", None))
        self.comboBox.setItemText(3, _translate("merge", "right", None))
        self.label_2.setText(_translate("merge", "Keys", None))
        self.pushButton_2.setText(_translate("merge", "YES", None))
        self.pushButton_3.setText(_translate("merge", "CANCEL", None))
        self.pushButton_4.setText(_translate("merge", "→", None))
        self.pushButton_5.setText(_translate("merge", "←", None))

