# -*- coding: utf-8 -*-

from PyQt4.QtGui import *
from PyQt4.QtCore import *
import sys

class generateDialog(QDialog):
    def __init__(self,parent=None):
        super(generateDialog,self).__init__(parent)
        self.setWindowTitle("Generate")
        self.equationText=QTextEdit()
        self.varCom=QComboBox()
        self.addButton=QPushButton("Add")
        self.clearButton=QPushButton("Clear")
        self.generateButton=QPushButton("Generate")
        closeButton=QPushButton("Close")
        vline=QFrame()
        leftLayout=QGridLayout()
        leftLayout.addWidget(self.equationText,0,0,1,3)
        leftLayout.addWidget(self.addButton,1,0,1,1)
        leftLayout.addWidget(self.varCom,1,1,1,2)
        leftLayout.addWidget(self.clearButton,2,0)
        leftLayout.addWidget(self.generateButton,2,1)
        leftLayout.addWidget(closeButton,2,2)
        #rightLayout=QVBoxLayout()
        #rightLayout.addWidget(clearButton)
        #rightLayout.addWidget(generateButton)
        #rightLayout.addWidget(closeButton)
        #mainLayout=QHBoxLayout()
        #mainLayout.addLayout(leftLayout)
        #mainLayout.addLayout(rightLayout)
        #self.setLayout(mainLayout)
        self.setLayout(leftLayout)
        self.connect(closeButton,SIGNAL("clicked()"),SLOT("close()"))
        #self.addButton.clicked.connect(self.addVR)
        self.clearButton.clicked.connect(self.clearText)

    def clearText(self):
        self.equationText.setText(str(""))

    #def addVAR(self):
        

#app=QApplication(sys.argv)
#dialog=generateDialog()
#dialog.show()
#app.exec_()
