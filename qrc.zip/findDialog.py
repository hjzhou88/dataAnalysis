# -----coding:utf-8-----

from PyQt4.QtCore import *
from PyQt4.QtGui import *
import sys

class findDialog(QDialog):
    def __init__(self,parent=None):
        super(findDialog,self).__init__(parent)
        self.setWindowTitle(self.tr("Find"))
        textLabel=QLabel("Find")
        self.textEdit=QLineEdit()
        self.findNextButton=QPushButton("Find Next")
        self.findAllButton=QPushButton("Find All")
        closeButton=QPushButton("Close")
        mainFrame=QFrame()
        mainLayout=QVBoxLayout()
        textLayout=QHBoxLayout()
        buttonLayout=QHBoxLayout()
        textLayout.addWidget(textLabel)
        textLayout.addWidget(self.textEdit)
        buttonLayout.addWidget(self.findNextButton)
        #buttonLayout.addWidget(self.findAllButton)
        buttonLayout.addWidget(closeButton)
        #mainLayout.addWidget(textLayout)   添加layout应采用addLayout方法
        mainLayout.addLayout(textLayout)
        #mainLayout.addWidget(buttonLayout)  添加layout应采用addLayout方法
        mainLayout.addLayout(buttonLayout)
        self.setLayout(mainLayout)
        self.connect(closeButton,SIGNAL("clicked()"),SLOT("close()"))


#app=QApplication(sys.argv)
#dialog=findDialog()
#dialog.show()
#app.exec_()
