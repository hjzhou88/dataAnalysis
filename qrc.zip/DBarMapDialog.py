# coding:utf-8
from PyQt4.QtCore import *
from PyQt4.QtGui import *
import sys
import os
from DBarMap import Ui_DBarMap


class DBarMapDialog(QDialog,Ui_DBarMap):
    def __init__(self,parent=None):
        super(DBarMapDialog,self).__init__(parent)
        self.setupUi(self)
        self.pushButton_3.clicked.connect(self.B3click)
        self.pushButton_4.clicked.connect(self.B4click)
        self.pushButton_5.clicked.connect(self.B5click)
        self.pushButton_6.clicked.connect(self.B6click)
        self.pushButton_7.clicked.connect(self.B7click)
        self.pushButton_8.clicked.connect(self.B8click)

    def B3click(self):
        index=self.listWidget.currentRow()
        self.listWidget_2.insertItem(index,self.listWidget.takeItem(index))

    def B4click(self):
        index=self.listWidget_2.currentRow()
        self.listWidget.insertItem(index,self.listWidget_2.takeItem(index))

    def B5click(self):
        #fileName=QFileDialog.getOpenFileName(self,"change path","C:\Users\Administrator\Desktop","Text Files (*.shp);;All Files (*)")   #设置文件扩展名过滤,注意用双分号间隔
        filePath=QFileDialog.getExistingDirectory()
        filePath.replace('\\',r'/')
        #print str(fileName)
        #fileName.replace('\','/')
        if not filePath.isEmpty():
            fileList=[]
            #self.lineEdit.setText(fileName)
            fileList=self.GetFileList(str(filePath),fileList)
            for i in range(0,len(fileList)):
                if fileList[i].endswith('json') or fileList[i].endswith('shp'):
                    self.listWidget.insertItem(i,fileList[i].replace('\\',r'/'))

    def GetFileList(self,dir,fileList):
        newDir = dir
        if os.path.isfile(dir):
            try:
                fileList.append(unicode(dir))
            except UnicodeDecodeError:
                fileList.append(dir)
                #print dir
            #fileList.append(dir.encode('gbk'))
        elif os.path.isdir(dir):
            for s in os.listdir(dir):
                #如果需要忽略某些文件夹，使用以下代码
                #if s == "xxx":
                #continue
                newDir=os.path.join(dir,s)
                self.GetFileList(newDir, fileList)
        return fileList

    def B6click(self):
        fcol=QColorDialog.getColor()
        if fcol.isValid():
            self.lineEdit_9.setText(fcol.name())
            #设置背景色
            self.lineEdit_9.setStyleSheet('QWidget { background-color: %s }' % fcol.name())  
            

    def B7click(self):
        col=QColorDialog.getColor()
        if col.isValid():
            self.lineEdit_8.setText(col.name())
            self.lineEdit_8.setStyleSheet('QWidget { background-color: %s }' % col.name())

    def B8click(self):
        col=QColorDialog.getColor()
        if col.isValid():
            self.lineEdit_7.setText(col.name())
            self.lineEdit_7.setStyleSheet('QWidget { background-color: %s }' % col.name())


