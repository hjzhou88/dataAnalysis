import cartopy.crs as ccrs
import matplotlib.pyplot as plt
import matplotlib as mpl
import cartopy.io.shapereader as shpreader
data=pd.read_csv("d:/r/2.csv")
shp=shpreader.Reader("d:/R/bou2_4p.shp")


def heatplot(shp,color,data):
    ax = plt.axes(projection=ccrs.PlateCarree())
    norm = mpl.colors.Normalize(vmin=data.min(axis=1), vmax=data.max(axis=1))
    #cmap = plt.cm.RdYlBu_r
    t="plt.cm."+color
    cmap=eval(t)
    f=[]
    for i in shp.records():
	try:
		k=ax.add_geometries(i.geometry,ccrs.PlateCarree(),facecolor=cmap(norm(data[i.attributes['NAME']])))
		f.append(k)
	except:
		pass
    plt.colorbar()
