from PyQt4.QtCore import *
from PyQt4.QtGui import *
import sys
from barMap import Ui_bar


class barMapDialog(QDialog,Ui_bar):
    def __init__(self,parent=None):
        super(barMapDialog,self).__init__(parent)
        self.setupUi(self)
        self.pushButton_3.clicked.connect(self.B3click)
        self.pushButton_4.clicked.connect(self.B4click)

    def B3click(self):
        index=self.listWidget.currentRow()
        self.listWidget_2.insertItem(index,self.listWidget.takeItem(index))

    def B4click(self):
        index=self.listWidget_2.currentRow()
        self.listWidget.insertItem(index,self.listWidget_2.takeItem(index))
