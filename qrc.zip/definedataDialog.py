# coding: utf-8

from PyQt4.QtGui import *
from PyQt4.QtCore import *
import sys


class definedate(QDialog):
    def __init__(self,parent=None):
        super(definedate,self).__init__(parent)
        self.setWindowTitle(self.tr("Define Date Variable"))
        gridLayout=QGridLayout()
        self.nameLabel=QLabel(self.tr("Name"))
        self.typeLabel=QLabel(self.tr('Period'))
        self.startLabel=QLabel(self.tr('Start Date'))
        self.endLabel=QLabel(self.tr('End Date'))
        self.comb=QComboBox()
        self.comb.addItem(self.tr("Monthly"))
        self.comb.addItem(self.tr("Annual"))
        
        self.comb.addItem(self.tr("Quaterly"))
        self.comb.addItem(self.tr("Date"))

        self.endText=QLineEdit()
        self.startText=QLineEdit()
        self.nameText=QLineEdit()

        self.okButton=QPushButton(self.tr("OK"))
        self.cancelButton=QPushButton(self.tr("Cancel"))
        #cancelButton.clicked.connect(self.close())
        gridLayout.addWidget(self.nameLabel,0,0)
        gridLayout.addWidget(self.nameText,0,1)

        gridLayout.addWidget(self.typeLabel,1,0)
        gridLayout.addWidget(self.comb,1,1)
        gridLayout.addWidget(self.startLabel,2,0)
        gridLayout.addWidget(self.startText,2,1)

        gridLayout.addWidget(self.endLabel,3,0)
        gridLayout.addWidget(self.endText,3,1)

        bottomLayout=QHBoxLayout()
        bottomLayout.addStretch()
        bottomLayout.addWidget(self.okButton)
        bottomLayout.addWidget(self.cancelButton)

        mainLayout=QVBoxLayout()
        mainLayout.addLayout(gridLayout)
        mainLayout.addLayout(bottomLayout)

        self.setLayout(mainLayout)   #此句加上方可显示girdLayout里的内容
        self.connect(self.cancelButton,SIGNAL("clicked()"),SLOT("close()"))
    

#app=QApplication(sys.argv)  
#main=definedate()  
#main.show()  
#app.exec_() 
