# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'addMap.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_addMap(object):
    def setupUi(self, addMap):
        addMap.setObjectName(_fromUtf8("addMap"))
        addMap.resize(437, 275)
        self.listWidget = QtGui.QListWidget(addMap)
        self.listWidget.setGeometry(QtCore.QRect(10, 50, 191, 221))
        self.listWidget.setObjectName(_fromUtf8("listWidget"))
        self.lineEdit = QtGui.QLineEdit(addMap)
        self.lineEdit.setGeometry(QtCore.QRect(10, 10, 113, 20))
        self.lineEdit.setObjectName(_fromUtf8("lineEdit"))
        self.pushButton = QtGui.QPushButton(addMap)
        self.pushButton.setGeometry(QtCore.QRect(130, 10, 75, 23))
        self.pushButton.setObjectName(_fromUtf8("pushButton"))
        self.groupBox = QtGui.QGroupBox(addMap)
        self.groupBox.setGeometry(QtCore.QRect(250, 20, 181, 221))
        self.groupBox.setObjectName(_fromUtf8("groupBox"))
        self.listWidget_2 = QtGui.QListWidget(self.groupBox)
        self.listWidget_2.setGeometry(QtCore.QRect(10, 20, 161, 101))
        self.listWidget_2.setObjectName(_fromUtf8("listWidget_2"))
        self.lineEdit_2 = QtGui.QLineEdit(self.groupBox)
        self.lineEdit_2.setGeometry(QtCore.QRect(100, 130, 71, 20))
        self.lineEdit_2.setObjectName(_fromUtf8("lineEdit_2"))
        self.lineEdit_3 = QtGui.QLineEdit(self.groupBox)
        self.lineEdit_3.setGeometry(QtCore.QRect(100, 160, 71, 20))
        self.lineEdit_3.setObjectName(_fromUtf8("lineEdit_3"))
        self.label_3 = QtGui.QLabel(self.groupBox)
        self.label_3.setGeometry(QtCore.QRect(20, 190, 54, 16))
        self.label_3.setObjectName(_fromUtf8("label_3"))
        self.lineEdit_4 = QtGui.QLineEdit(self.groupBox)
        self.lineEdit_4.setGeometry(QtCore.QRect(100, 190, 71, 20))
        self.lineEdit_4.setObjectName(_fromUtf8("lineEdit_4"))
        self.pushButton_6 = QtGui.QPushButton(self.groupBox)
        self.pushButton_6.setGeometry(QtCore.QRect(10, 130, 71, 23))
        self.pushButton_6.setObjectName(_fromUtf8("pushButton_6"))
        self.pushButton_7 = QtGui.QPushButton(self.groupBox)
        self.pushButton_7.setGeometry(QtCore.QRect(10, 160, 71, 23))
        self.pushButton_7.setObjectName(_fromUtf8("pushButton_7"))
        self.pushButton_2 = QtGui.QPushButton(addMap)
        self.pushButton_2.setGeometry(QtCore.QRect(250, 250, 75, 23))
        self.pushButton_2.setObjectName(_fromUtf8("pushButton_2"))
        self.pushButton_3 = QtGui.QPushButton(addMap)
        self.pushButton_3.setGeometry(QtCore.QRect(340, 250, 75, 23))
        self.pushButton_3.setObjectName(_fromUtf8("pushButton_3"))
        self.pushButton_4 = QtGui.QPushButton(addMap)
        self.pushButton_4.setGeometry(QtCore.QRect(210, 50, 31, 31))
        self.pushButton_4.setObjectName(_fromUtf8("pushButton_4"))
        self.pushButton_5 = QtGui.QPushButton(addMap)
        self.pushButton_5.setGeometry(QtCore.QRect(210, 100, 31, 31))
        self.pushButton_5.setObjectName(_fromUtf8("pushButton_5"))

        self.retranslateUi(addMap)
        QtCore.QMetaObject.connectSlotsByName(addMap)

    def retranslateUi(self, addMap):
        addMap.setWindowTitle(_translate("addMap", "addMap", None))
        self.pushButton.setText(_translate("addMap", "Change Path", None))
        self.groupBox.setTitle(_translate("addMap", "GEO File Selection", None))
        self.lineEdit_2.setText(_translate("addMap", "grey", None))
        self.lineEdit_3.setText(_translate("addMap", "black", None))
        self.label_3.setText(_translate("addMap", "Alpha", None))
        self.lineEdit_4.setText(_translate("addMap", "0.5", None))
        self.pushButton_6.setText(_translate("addMap", "FaceColor", None))
        self.pushButton_7.setText(_translate("addMap", "EdgeColor", None))
        self.pushButton_2.setText(_translate("addMap", "YES", None))
        self.pushButton_3.setText(_translate("addMap", "CANCEL", None))
        self.pushButton_4.setText(_translate("addMap", "→", None))
        self.pushButton_5.setText(_translate("addMap", "←", None))

