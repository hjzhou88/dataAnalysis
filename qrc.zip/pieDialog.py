# coding: utf-8

from PyQt4.QtGui import *
from PyQt4.QtCore import *
import sys
import palettable.colorbrewer as cb
import palettable.tableau as tb
import palettable.wesanderson as wd


class pieDialog(QDialog):
    def __init__(self,parent=None):
        super(pieDialog,self).__init__(parent)
        self.setWindowTitle(self.tr("Pie"))
        gridLayout=QGridLayout()
        self.nameLabel=QLabel(self.tr("Data"))
        self.labelsLabel=QLabel(self.tr('Label'))
        self.explodeLabel=QLabel(self.tr('Explode'))
        self.shadowLabel=QLabel(self.tr('Shadow'))
        counterclockLabel=QLabel(self.tr('CounterClock'))
        
        self.styleLabel=QLabel(self.tr('Style'))
        self.dataComb=QComboBox()
        self.labelsComb=QComboBox()
        self.explodeComb=QComboBox()
        self.shadowComb=QComboBox()
        self.styleComb=QComboBox()
        self.counterclock=QComboBox()
        
        self.shadowComb.addItem(self.tr("True"))
        self.shadowComb.addItem(self.tr("False"))
        self.counterclock.addItem(self.tr("True"))
        self.counterclock.addItem(self.tr("False"))
        self.styleComb.addItem(self.tr("None"))
        self.explodeComb.addItem(self.tr("None"))

        self.radiusLabel=QLabel(self.tr('Radius'))
        self.startAngleLabel=QLabel(self.tr('StartAngle'))
        self.labelDistanceLabel=QLabel(self.tr('LabelDistance'))
        self.autopctLabel=QLabel(self.tr('Autopct'))
        self.radiusText=QLineEdit()
        self.startAngleText=QLineEdit()
        self.labelDistanceText=QLineEdit()
        self.autopctText=QLineEdit()
        self.labelDistanceText.setText('1.1')
        self.radiusText.setText('0.5')
        self.startAngleText.setText('0')
        self.autopctText.setText('None')

        self.okButton=QPushButton(self.tr("OK"))
        self.cancelButton=QPushButton(self.tr("Cancel"))
        #cancelButton.clicked.connect(self.close())
        gridLayout.addWidget(self.nameLabel,0,0)
        gridLayout.addWidget(self.dataComb,0,1)
        gridLayout.addWidget(self.labelsLabel,0,2)
        gridLayout.addWidget(self.labelsComb,0,3)
        
        gridLayout.addWidget(self.explodeLabel,1,0)
        gridLayout.addWidget(self.explodeComb,1,1)
        gridLayout.addWidget(self.shadowLabel,1,2)
        gridLayout.addWidget(self.shadowComb,1,3)
        gridLayout.addWidget(self.styleLabel,2,0)
        gridLayout.addWidget(self.styleComb,2,1)
        gridLayout.addWidget(counterclockLabel,2,2)
        gridLayout.addWidget(self.counterclock,2,3)

        gridLayout2=QHBoxLayout()
        gridLayout.addWidget(self.labelDistanceLabel,3,0)
        gridLayout.addWidget(self.labelDistanceText,3,1)
        gridLayout.addWidget(self.radiusLabel,3,2)
        gridLayout.addWidget(self.radiusText,3,3)
        gridLayout.addWidget(self.startAngleLabel,4,0)
        gridLayout.addWidget(self.startAngleText,4,1)
        gridLayout.addWidget(self.autopctLabel,4,2)
        gridLayout.addWidget(self.autopctText,4,3)
        
        
        self.okButton=QPushButton(self.tr("Yes"))
        cancelButton=QPushButton(self.tr("Cancel"))
        colorButton=QPushButton(self.tr("MoreColor"))
        #colorButton.clicked.connect(self.slotEx)
        self.connect(colorButton,SIGNAL("clicked()"),self.slotExtension)  #扩展信号
        btnBox=QDialogButtonBox(Qt.Horizontal)
        btnBox.addButton(self.okButton,QDialogButtonBox.ActionRole)
        btnBox.addButton(cancelButton,QDialogButtonBox.ActionRole)
        btnBox.addButton(colorButton,QDialogButtonBox.ActionRole)
        
        gridLayout2.addStretch()
        gridLayout2.addWidget(self.okButton)
        gridLayout2.addWidget(cancelButton)
        gridLayout2.addWidget(colorButton)
        #gridLayout2.addWidget(self.okButton,0,1)
        #gridLayout2.addWidget(cancelButton,0,2)
        #gridLayout2.addWidget(colorButton,0,3)

        self.detailWidget=QWidget()
        self.colorLayout=QGridLayout(self.detailWidget)
        hcolorLayout=QHBoxLayout()
        cycleColorLabel=QLabel(self.tr('ColorSet'))
        self.lineEdit_2=QLineEdit()
        hcolorLayout.addWidget(self.lineEdit_2)
        hcolorLayout.addWidget(cycleColorLabel)
        self.tree=QTreeWidget()
        self.tree.itemDoubleClicked.connect(self.TreeDBclick)
        #self.connect(self.tree,SIGNAL("itemDoubleClicked()"),self.TreeDBclick)  #双击信号
        self.tree.setColumnCount(1)
        self.tree.setHeaderLabels(['COLOR_MAPS'])
        palettable= QTreeWidgetItem(self.tree)
        palettable.setText(0,'palettable')
        colorbrewer=QTreeWidgetItem(palettable)
        colorbrewer.setText(0,'colorbrewer')
        diverging=QTreeWidgetItem(colorbrewer)
        diverging.setText(0,'diverging')
        divergingList=cb.COLOR_MAPS['Diverging'].keys()
        #print QualitativeList
        for i in divergingList:
            colorName=i
            colorName=QTreeWidgetItem(diverging)
            colorName.setText(0,i)
            listI=cb.COLOR_MAPS['Diverging'][i].keys()
            for j in listI:
                colorNumber1=QTreeWidgetItem(colorName)
                colorNumber1.setText(0,i+'_'+j)
                colorNumber2=QTreeWidgetItem(colorName)
                colorNumber2.setText(0,i+'_'+j+'_r')
        qualitative=QTreeWidgetItem(colorbrewer)
        qualitative.setText(0,'qualitative')
        QualitativeList=cb.COLOR_MAPS['Qualitative'].keys()
        #print QualitativeList
        for i in QualitativeList:
            colorName=i
            colorName=QTreeWidgetItem(qualitative)
            colorName.setText(0,i)
            listI=cb.COLOR_MAPS['Qualitative'][i].keys()
            for j in listI:
                colorNumber1=QTreeWidgetItem(colorName)
                colorNumber1.setText(0,i+'_'+j)
                colorNumber2=QTreeWidgetItem(colorName)
                colorNumber2.setText(0,i+'_'+j+'_r')
                
        sequential=QTreeWidgetItem(colorbrewer)
        sequential.setText(0,'sequential')
        sequentialList=cb.COLOR_MAPS['Sequential'].keys()
        #print QualitativeList
        for i in sequentialList:
            colorName=i
            colorName=QTreeWidgetItem(sequential)
            colorName.setText(0,i)
            listI=cb.COLOR_MAPS['Sequential'][i].keys()
            for j in listI:
                colorNumber1=QTreeWidgetItem(colorName)
                colorNumber1.setText(0,i+'_'+j)
                colorNumber2=QTreeWidgetItem(colorName)
                colorNumber2.setText(0,i+'_'+j+'_r')
        
        tableau=QTreeWidgetItem(palettable)
        tableau.setText(0,'tableau')
        qualitative=QTreeWidgetItem(tableau)
        qualitative.setText(0,'qualitative')
        colorList=tb.tableau.palette_names
        for i in colorList:
            colorName1=i
            colorName1=QTreeWidgetItem(qualitative)
            colorName1.setText(0,i)
            colorName2=i
            colorName2=QTreeWidgetItem(qualitative)
            colorName2.setText(0,i+'_r')
        wesanderson=QTreeWidgetItem(palettable)
        wesanderson.setText(0,'wesanderson')
        qualitative=QTreeWidgetItem(wesanderson)
        qualitative.setText(0,'qualitative')
        colorList=wd.wesanderson._get_all_maps().keys()
        for i in colorList:
            colorName=i
            colorName=QTreeWidgetItem(qualitative)
            colorName.setText(0,i)
        self.colorLayout.addLayout(hcolorLayout,0,0)
        self.colorLayout.addWidget(self.tree,1,0)

        self.detailWidget.hide()  #先隐藏

        mainLayout=QVBoxLayout()
        mainLayout.addLayout(gridLayout)
        mainLayout.addLayout(gridLayout2)
        mainLayout.addWidget(self.detailWidget)
        mainLayout.setSizeConstraint(QLayout.SetFixedSize)
        mainLayout.setSpacing(10)
        self.setLayout(mainLayout)   #此句加上方可显示Layout里的内容

    def slotExtension(self):
        if self.detailWidget.isHidden():
            self.detailWidget.show()
        else:
            self.detailWidget.hide()

        #def slotExtension(self):  #对齐方式不对
            #if self.detailWidget.isHidden():
                #self.detailWidget.show()
            #else:
                #self.detailWidget.hide()
    def TreeDBclick(self):
        if unicode(self.tree.currentItem().parent().text(self.tree.currentColumn()))!='qualitative':
            PColorItem=unicode(self.tree.currentItem().parent().parent().text(self.tree.currentColumn()))+"."  #text里面带列号才能获得文本
        else:
            PColorItem=""
        colorItem=unicode(self.tree.currentItem().text(self.tree.currentColumn()))
        self.lineEdit_2.setText(PColorItem+colorItem)
    

#app=QApplication(sys.argv)  
#main=pieDialog()  
#main.show()  
#app.exec_() 
