# -*- coding: utf-8 -*-
from PyQt4.QtCore import *
from PyQt4.QtGui import *
import sys
import os
from addMap import Ui_addMap


class addMapDialog(QDialog,Ui_addMap):
    def __init__(self,parent=None):
        super(addMapDialog,self).__init__(parent)
        self.setupUi(self)
        cmaps = [('Perceptually Uniform Sequential',
                            ['viridis', 'inferno', 'plasma', 'magma']),
         ('Sequential',     ['Blues', 'BuGn', 'BuPu',
                             'GnBu', 'Greens', 'Greys', 'Oranges', 'OrRd',
                             'PuBu', 'PuBuGn', 'PuRd', 'Purples', 'RdPu',
                             'Reds', 'YlGn', 'YlGnBu', 'YlOrBr', 'YlOrRd']),
         ('Sequential (2)', ['afmhot', 'autumn', 'bone', 'cool',
                             'copper', 'gist_heat', 'gray', 'hot',
                             'pink', 'spring', 'summer', 'winter']),
         ('Diverging',      ['BrBG', 'bwr', 'coolwarm', 'PiYG', 'PRGn', 'PuOr',
                             'RdBu', 'RdGy', 'RdYlBu', 'RdYlGn', 'Spectral',
                             'seismic']),
         ('Qualitative',    ['Accent', 'Dark2', 'Paired', 'Pastel1',
                             'Pastel2', 'Set1', 'Set2', 'Set3']),
         ('Miscellaneous',  ['gist_earth', 'terrain', 'ocean', 'gist_stern',
                             'brg', 'CMRmap', 'cubehelix',
                             'gnuplot', 'gnuplot2', 'gist_ncar',
                             'nipy_spectral', 'jet', 'rainbow',
                             'gist_rainbow', 'hsv', 'flag', 'prism'])]
        nrows = max(len(cmap_list) for cmap_category, cmap_list in cmaps)
        self.listWidget.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.listWidget_2.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.pushButton.clicked.connect(self.Bclick)
        self.pushButton_4.clicked.connect(self.B4click)
        self.pushButton_5.clicked.connect(self.B5click)
        self.pushButton_6.clicked.connect(self.B6click)
        self.pushButton_6.clicked.connect(self.B7click)

    def Bclick(self):
        #fileName=QFileDialog.getOpenFileName(self,"change path","C:\Users\Administrator\Desktop","Text Files (*.shp);;All Files (*)")   #设置文件扩展名过滤,注意用双分号间隔
        fileName=QFileDialog.getExistingDirectory()
        fileName.replace('\\',r'/')
        #print str(fileName)
        #fileName.replace('\','/')
        if not fileName.isEmpty():
            fileList=[]
            self.lineEdit.setText(fileName)
            fileList=self.GetFileList(str(fileName),fileList)
            for i in range(0,len(fileList)):
                
                self.listWidget.insertItem(i,fileList[i].replace('\\',r'/'))
            

    def B4click(self):
        lenlist=len(self.listWidget.selectedItems())
        while (lenlist!=0):
            index=self.listWidget.currentRow()
            self.listWidget_2.insertItem(index,self.listWidget.takeItem(index))
            lenlist=lenlist-1

    def B5click(self):
        lenlist=len(self.listWidget_2.selectedItems())
        while (lenlist!=0):
            index=self.listWidget_2.currentRow()
            self.listWidget.insertItem(index,self.listWidget_2.takeItem(index))
            lenlist=lenlist-1

    def GetFileList(self,dir,fileList):
        newDir = dir
        if os.path.isfile(dir):
            fileList.append(dir.encode('gbk'))
        elif os.path.isdir(dir):
            for s in os.listdir(dir):
                #如果需要忽略某些文件夹，使用以下代码
                #if s == "xxx":
                #continue
                newDir=os.path.join(dir,s)
                self.GetFileList(newDir, fileList)
        return fileList

    def B6click(self):
        fcol=QColorDialog.getColor()
        if fcol.isValid():
            self.lineEdit_2.setText(fcol.name())
            #设置背景色
            self.lineEdit_2.setStyleSheet('QWidget { background-color: %s }' % fcol.name())  
            

    def B7click(self):
        col=QColorDialog.getColor()
        if col.isValid():
            self.lineEdit_3.setText(col.name())
            self.lineEdit_3.setStyleSheet('QWidget { background-color: %s }' % col.name())

    
