from PyQt4.QtCore import *
from PyQt4.QtGui import *
import sys
from bubbleMap import Ui_bubble
#from addMapDialog import addMapDialog


class bubbleMapDialog(QDialog,Ui_bubble):
    def __init__(self,parent=None):
        super(bubbleMapDialog,self).__init__(parent)
        self.setupUi(self)
        #self.pushButton_3.clicked.connect(self.B3click)

    #def B3click(self):
        #self.addMapLD=addMapDialog()
        #self.addMapLD.exec_()

