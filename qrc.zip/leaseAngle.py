# -*- coding: utf-8 -*-
from numpy import *

class leastAngle:
    #数据进行标准化
    def zscore(self,dataSet):
	n,p=dataSet.shape
	meanVal=mean(dataSet,axis=0)
	meanMinus=dataSet-meanVal
	print meanVal
	stdVal=std(dataSet,axis=0)
	print stdVal
	zscore=meanMinus/(stdVal*sqrt(n))
	return zscore

#求最小二乘法的回归系数
    def findbeta(self,xdata,ydata):
	matxdata=mat(xdata)
	matydata=mat(ydata)
	beta=linalg.inv(matxdata.T*matxdata)*matxdata.T*matydata
	return beta
#求Cp
    def cpf(self,beta,xdata,ydata,step):
	beta1=self.findbeta(mat(xdata),mat(ydata))
	n,p=xdata.shape
	u=xdata*beta1
	s=float((mat(ydata)-u).T*(mat(ydata)-u))/(n-p-1)
	udata=mat(xdata)*mat(beta)
	Rss=float((mat(ydata)-udata).T*(mat(ydata)-udata))
	df=step
	cp=Rss/s-n+2*step
	return Rss,df,cp

#判别量的选择
    def summary(self,beta,x_data,y_data):
	x=self.zscore(mat(x_data.astype(float)))
	y=mat(y_data.astype(float))-mean(mat(y_data.astype(float)),axis=0)
	n,p=beta.shape
	rss=['Rss']
	df=['df']
	cp=['Cp']
	for i in range(p):
		be=beta[:,i:(i+1)] #注意矩阵中beta[:,i:(i+1)]引用与beta[:,i]不同
		temp_rss,temp_df,temp_cp=self.cpf(be,x,y,i+1)
		rss.append(temp_rss)
	        df.append(temp_df)
	        cp.append(temp_cp)
        result=column_stack((mat(df).T,mat(rss).T))
        result=column_stack((result,mat(cp).T))
	return result


#求方差
    def s(self,xdata,ydata):
	beta=self.findbeta(mat(xdata),mat(ydata))
	n,p=xdata.shape
	u=xdata*beta
	s=float((mat(ydata)-u).T*(mat(ydata)-u))/(n-p-1)
	return s

#lars方法回归
    def lar(self,x_data,y_data):
        x_data=mat(x_data.astype(float))
        y_data=mat(y_data.astype(float))
	xstd_data=self.zscore(x_data)  #调用自定义函数zscore
	ystd_data=mat(y_data)-mean(mat(y_data),axis=0)
	n,dim=mat(xstd_data).shape
        Ac=[i for i in range(dim)]
	y=zeros((n,1))
	a=[]
	s=zeros((n,1))
	c=mat(xstd_data).T*(mat(ystd_data.reshape(n,1)-y)) #(n,)和(n,1)是不同的数据,需要转化
	beta=zeros((dim,1))
	temp_beta=zeros((dim,1))
	dj=zeros((dim,1))
	while True:
		c_abs=abs(c)
                temp_c=c_abs
		for i in a:
			temp_c[i,0]=0             #去掉已经入队的变量
		a_absSort=argsort(temp_c,axis=0)  #axis=0表示按列
		index_max=a_absSort[-1:-2:-1]
		a.append(int(index_max))
		s[index_max]=c_abs[index_max,0]/c[index_max,0]
		if len(a)==1:
			Xa=xstd_data[:,int(index_max)]
			Xa=Xa*s[int(index_max)]
		else:
			temp_x=xstd_data[:,int(index_max)]*s[int(index_max)]
			Xa=column_stack((Xa,temp_x))
                E=ones((len(a),1))  #相当于文中1A,其长度为入选向量集合的大小
		G=mat(Xa).T*mat(Xa)
		Aa=1/sqrt(E.T*linalg.inv(G)*E)
		wa=float(Aa)*linalg.inv(G)*E
		ln,dd=wa.shape
		ya=mat(Xa)*wa    #相当于文中ua
		b=mat(xstd_data.T)*ya  #相当于文中a
		r=[]
		Ac=filter(lambda x: x!=int(index_max),Ac)  #未入选的变量集合
                for i in range(len(a)):
			dj[a[i],0]=wa[i,0]*s[a[i]]    #beta的方向
                if len(a)==dim:
			break
		for j in Ac:
			temp_r1=min((c_abs[int(index_max),0]-c[j,0])/(Aa-b[j,0]),(c_abs[int(index_max),0]+c[j,0])/(Aa+b[j,0]))
			temp_r2=max((c_abs[int(index_max),0]-c[j,0])/(Aa-b[j,0]),(c_abs[int(index_max),0]+c[j,0])/(Aa+b[j,0]))
			if temp_r1>0:
				r.append(temp_r1)
			else:
				if temp_r2>0:
					r.append(temp_r2)
		r_final=float(min(r))
		temp_beta=temp_beta+r_final*dj
		y=mat(xstd_data)*mat(temp_beta)
		beta=column_stack((beta,temp_beta))
		c=mat(xstd_data).T*(mat(ystd_data.reshape(n,1)-y))
	temp_beta=self.findbeta(xstd_data,ystd_data.reshape(n,1)) #调用自定义函数findbeta
	beta=column_stack((beta,temp_beta))
	return a,array(beta)

    def larlasso(self,x_data,y_data):
        x_data=mat(x_data.astype(float))
        y_data=mat(y_data.astype(float))
	xstd_data=self.zscore(x_data)  #调用自定义函数zscore
	ystd_data=mat(y_data)-mean(mat(y_data),axis=0)
	n,dim=mat(xstd_data).shape
        Ac=[i for i in range(dim)]
	y=zeros((n,1))
	a=[]
	s=zeros((n,1))
	c=mat(xstd_data).T*(mat(ystd_data.reshape(n,1)-y)) #(n,)和(n,1)是不同的数据,需要转化
	beta=zeros((dim,1))
	temp_beta=zeros((dim,1))
	dj=zeros((dim,1))
	temp_beta0=self.findbeta(xstd_data,ystd_data.reshape(n,1)) #调用自定义函数findbeta
	while True:
		c_abs=abs(c)
                temp_c=c_abs
		for i in a:
			temp_c[i,0]=0             #去掉已经入队的变量
		a_absSort=argsort(temp_c,axis=0)  #axis=0表示按列
		index_max=a_absSort[-1:-2:-1]
		a.append(int(index_max))
		s[index_max]=c_abs[index_max,0]/c[index_max,0]
		if len(a)==1:
			Xa=xstd_data[:,int(index_max)]
			Xa=Xa*s[int(index_max)]
		else:
			temp_x=xstd_data[:,int(index_max)]*s[int(index_max)]
			Xa=column_stack((Xa,temp_x))
                E=ones((len(a),1))  #相当于文中1A,其长度为入选向量集合的大小
		G=mat(Xa).T*mat(Xa)
		Aa=1/sqrt(E.T*linalg.inv(G)*E)
		wa=float(Aa)*linalg.inv(G)*E
		ln,dd=wa.shape
		ya=mat(Xa)*wa    #相当于文中ua
		b=mat(xstd_data.T)*ya  #相当于文中a
		r=[]
		Ac=filter(lambda x: x!=int(index_max),Ac)  #未入选的变量集合
                for i in range(len(a)):
			dj[a[i],0]=wa[i,0]*s[a[i]]    #beta的方向

		if len(Ac)==0:
			r_final=float(((temp_beta0-temp_beta)/dj)[0])
			#print r_final
		else:
			for j in Ac:
				temp_r1=min((c_abs[int(index_max),0]-c[j,0])/(Aa-b[j,0]),(c_abs[int(index_max),0]+c[j,0])/(Aa+b[j,0]))
				temp_r2=max((c_abs[int(index_max),0]-c[j,0])/(Aa-b[j,0]),(c_abs[int(index_max),0]+c[j,0])/(Aa+b[j,0]))
				if temp_r1>0:
					r.append(temp_r1)
				else:
					if temp_r2>0:
						r.append(temp_r2)
			r_final=float(min(r))
			#print r_final
		rj=[]                                           #此处开始因为lasso算法增加
		for i in a:
			temp_rj=float(-temp_beta[i,:]/dj[i,:])
			rj.append(temp_rj)

		r0=float(max(rj))
		jj=argsort(rj)[-1:-2:-1]
		if r0>0:
			for i in range(len(rj)):
				if rj[i]>0 and rj[i]<r0:
					r0=float(rj[i])
					jj=i

			if r0<r_final:
				r_final=r0
				print a[jj]
				Ac.append(a[jj])
				Xa=delete (Xa,a[jj],1)
				del a[jj]              #此处结束
				#print Xa.shape
		if len(a)==dim:
			break
		temp_beta=temp_beta+r_final*dj
		y=mat(xstd_data)*mat(temp_beta)
		beta=column_stack((beta,temp_beta))
		c=mat(xstd_data).T*(mat(ystd_data.reshape(n,1)-y))
	temp_beta=self.findbeta(xstd_data,ystd_data.reshape(n,1)) #调用自定义函数findbeta
	beta=column_stack((beta,temp_beta0))
	return a,array(beta)
